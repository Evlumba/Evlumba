import { redirect } from "next/navigation";
import { getCurrentAdminContext } from "@/lib/admin/access";
import AdminDashboardClient from "./AdminDashboardClient";

export const dynamic = "force-dynamic";
export const revalidate = 0;

export default async function AdminPage() {
  const adminContext = await getCurrentAdminContext();

  if (!adminContext) {
    redirect("/admin/login?next=%2Fadmin");
  }

  return (
    <AdminDashboardClient
      currentRole={adminContext.role}
      currentUserId={adminContext.userId}
    />
  );
}
